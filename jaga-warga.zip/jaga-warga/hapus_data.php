<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['nik'])) {
        $nik = $_GET['nik'];

        // Query hapus data
        $query = "DELETE FROM tbl_warga_kk WHERE nik='$nik'";

        if (mysqli_query($koneksi, $query)) {
            // Jika hapus data berhasil
            echo '<script>alert("Data berhasil dihapus"); window.location.href="index.php";</script>';
        } else {
            // Jika hapus data gagal
            echo '<script>alert("Terjadi kesalahan saat menghapus data"); window.location.href="index.php";</script>';
        }
    } else {
        // Jika parameter nik tidak ditemukan
        echo '<script>window.location.href="index.php";</script>';
    }
} else {
    // Jika akses langsung ke file ini tanpa melalui URL
    echo '<script>window.location.href="index.php";</script>';
}
?>