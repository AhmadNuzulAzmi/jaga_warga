<?php
include 'koneksi.php';
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Warga</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
</head>

<body>
    <h3 class="mt-3">Data Warga</h3>
    <div class="conten mt-3">
        <div class="col-lg-12">
            <a href="input_data.php" class="btn btn-primary mt-3 mb-3">+ Tambah Data</a>
            <table id="table-data" class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">NIK</th>
                        <th scope="col">No KK</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Status</th>
                        <th scope="col">Pendidikan Terakhir</th>
                        <th scope="col">Kelas</th>
                        <th scope="col">Pekerjaan</th>
                        <th scope="col">Penghasilan</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM tbl_warga_kk");
                        while($row = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <th scope="row"><?= $no++ ?></th>
                        <td><?= $row['nik'] ?></td>
                        <td><?= $row['no_kk'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td><?= $row['stat'] ?></td>
                        <td><?= $row['pendidikan'] ?></td>
                        <td><?= $row['kelas'] ?></td>
                        <td><?= $row['pekerjaan'] ?></td>
                        <td><?= $row['penghasilan'] ?></td>
                        <td>
                            <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                data-target="#edit<?= $row['nik'] ?>">Edit</button>
                            <a href="hapus_data.php?nik=<?= $row['nik']; ?>" class="btn btn-danger btn-sm"
                                onclick="return confirm('Apakah Anda Yakin Menghapus Data Ini?');">Hapus</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Edit Data -->
    <?php
        $query_edit = mysqli_query($koneksi, "SELECT * FROM tbl_warga_kk");
        while($row_edit = mysqli_fetch_array($query_edit)){
    ?>
    <div class="modal fade" id="edit<?= $row_edit['nik'] ?>" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Tambahkan form untuk mengedit data -->
                    <form action="prs_edit_data.php" method="POST">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" class="form-control" id="nik" name="nik" value="<?= $row_edit['nik'] ?>"
                                readonly>
                        </div>
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" id="nama" name="nama"
                                value="<?= $row_edit['nama'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="stat">Status</label>
                            <input type="text" class="form-control" id="stat" name="stat"
                                value="<?= $row_edit['stat'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="pendidikan">Pendidikan Terakhir</label>
                            <input type="text" class="form-control" id="pendidikan" name="pendidikan"
                                value="<?= $row_edit['pendidikan'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="kelas">Kelas</label>
                            <input type="text" class="form-control" id="kelas" name="kelas"
                                value="<?= $row_edit['kelas'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="pekerjaan">Pekerjaan</label>
                            <input type="text" class="form-control" id="pekerjaan" name="pekerjaan"
                                value="<?= $row_edit['pekerjaan'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="penghasilan">Penghasilan</label>
                            <input type="text" class="form-control" id="penghasilan" name="penghasilan"
                                value="<?= $row_edit['penghasilan'] ?>" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>

    <script>
    $(document).ready(function() {
        $('#table-data').DataTable();
    });
    </script>
</body>

</html>