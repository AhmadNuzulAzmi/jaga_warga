<!doctype html>
<html>

<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Klik Jaga Warga</title>
    <link href='https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
    <link href='style/style.css' rel='stylesheet'>
    <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

</head>

<body className='snippet-body'>
    <div class="container mt-5">
        <div class="row d-flex justify-content-center align-items-center">
            <div class="col-md-8">
                <form id="regForm" action="simpan_data.php" method="POST">
                    <h1 id="register">Klik Jaga Warga</h1>
                    <div class="all-steps" id="all-steps">
                        <span class="step"><i class="fa fa-users"></i></span>
                    </div>

                    <div id="additionalTabs">
                        <div class="tab">
                            <h6> No KK </h6>
                            <p><input type="number" placeholder="NIK" name="no_kk" required></p>
                            <h6> Nama Kepala Keluarga </h6>
                            <p><input placeholder="Nama " oninput="this.className = ''" name="nama_kepala" required>
                            </p>
                            <!-- <h6>Bukti Sensus</h6>
                            <p><input type="file" name="gambar" class="form-control" onchange="previeww()"></p>
                            <img style="center" id="thumb" width="30%"> -->


                        </div>

                    </div>

                    <div style="overflow:auto;" id="nextprevious">
                        <div style="float:right;">
                            <button type="button" id="prevBtn" onclick="nextPrev(-1)" class="btn btn-outline-success"><i
                                    class="fa fa-angle-double-left"></i></button>
                            <button type="button" id="nextBtn" onclick="nextPrev(1)" class="btn btn-outline-success"><i
                                    class="fa fa-angle-double-right"></i></button>
                            <button type="submit" class="btn btn-outline-primary" id="btn_submit"><i
                                    class="fa fa-check-square-o"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script type='text/javascript' src='https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js'>
    </script>
    <script type='text/javascript' src='https://code.jquery.com/jquery-3.6.0.min.js'></script>
    <script type='text/javascript' src='js/app.js'>

    </script>
</body>

</html>