function previeww() {
  thumb.src = URL.createObjectURL(event.target.files[0]);
}

addNewTab();

var currentTab = 0;
document.addEventListener("DOMContentLoaded", function (event) {
  showTab(currentTab);
});

function showTab(n) {
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == x.length - 1) {
    document.getElementById("nextBtn").innerHTML = '<i class="fa fa-plus"></i>';
  } else {
    document.getElementById("nextBtn").innerHTML =
      '<i class="fa fa-angle-double-right"></i>';
  }
  fixStepIndicator(n);
}

function nextPrev(n) {
  var x = document.getElementsByClassName("tab");
  if (n == 1 && !validateForm()) return false;
  x[currentTab].style.display = "none";
  currentTab = currentTab + n;
  if (currentTab >= x.length) {
    addNewTab();
    currentTab = x.length - 1;
  }
  showTab(currentTab);
}

function validateForm() {
  var x,
    y,
    i,
    valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  for (i = 0; i < y.length; i++) {
    if (y[i].value == "") {
      y[i].className += " invalid";
      valid = false;
    }
  }
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid;
}

function fixStepIndicator(n) {
  var i,
    x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  x[n].className += " active";
}

function addNewTab() {
  var spanI = document.getElementById("all-steps");
  var tabContent1 = `
            <span class="step"><i class="fa fa-user"></i></span>`;

  spanI.insertAdjacentHTML("beforeend", tabContent1);
  var additionalTabs = document.getElementById("additionalTabs");
  var tabContent = `
         
        <div class="tab">
            <h6> NIK </h6>
            <p><input type="number" placeholder="NIK" name="nik[]" required></p>
            <h6> Nama </h6>
            <p><input type="text" placeholder="Nama " oninput="this.className = ''" name="nama[]"></p>
            <h6> Status </h6>
            <p><select name="status[]" class="form-control" required> 
                <option value="">Pilih status</option>
                <option value="Belum Menikah">Belum Menikah</option>
                <option value="Menikah">Menikah</option>
                <option value="Duda">Duda</option>
                <option value="Janda">Janda</option>
            </select></p>
            <h6> Pendidikan Terakhir </h6>
            <p><select name="pendidikan[]" class="form-control" required>
                <option value="">Pilih pendidikan</option>
                <option value="SD">SD</option>
                <option value="SMP">SMP</option>
                <option value="SMA">SMA</option>
                <option value="Diploma">Diploma</option>
                <option value="Sarjana">Sarjana</option>
                <option value="Magister">Magister</option>
                <option value="Doktor">Doktor</option>
            </select></p>
            <h6> Kelas </h6>
            <p><input type="number" placeholder="Kelas" oninput="this.className = ''" name="kelas[]" required></p>
            <h6> Pekerjaan </h6>
            <p><input placeholder="Pekerjaan" oninput="this.className = ''" name="pekerjaan[]" required></p>
            <h6> Penghasilan </h6>
            <p><input type="number" placeholder="Penghasilan" oninput="this.className = ''" name="penghasilan[]" required></p>
            <button class="btn btn-outline-danger" onclick="removeTab(this)">-</button>
        </div>
    `;
  additionalTabs.insertAdjacentHTML("beforeend", tabContent);
}

function removeTab(button) {
  var tabToRemove = button.parentNode;
  tabToRemove.parentNode.removeChild(tabToRemove);
  currentTab--;
  showTab(currentTab);
}
