<?php
// Menghubungkan ke database MySQL
$host = "localhost";
$user = "root";
$pass = "";
$db   = "warga_db";

$koneksi = mysqli_connect($host,$user,$pass,$db);
// Memeriksa koneksi database
if (!$koneksi) {
    die('Koneksi database gagal: ' . mysqli_koneksiect_error());
}
?>