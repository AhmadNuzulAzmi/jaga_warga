<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $stat = $_POST['stat'];
    $pendidikan = $_POST['pendidikan'];
    $kelas = $_POST['kelas'];
    $pekerjaan = $_POST['pekerjaan'];
    $penghasilan = $_POST['penghasilan'];

    // Query update data
    $query = "UPDATE tbl_warga_kk SET nama='$nama', stat='$stat', pendidikan='$pendidikan', kelas='$kelas', pekerjaan='$pekerjaan', penghasilan='$penghasilan' WHERE nik='$nik'";

    if (mysqli_query($koneksi, $query)) {
        // Jika update data berhasil
        echo '<script>alert("Data berhasil diubah"); window.location.href="index.php";</script>';
    } else {
        // Jika update data gagal
        echo '<script>alert("Terjadi kesalahan saat mengubah data"); window.location.href="index.php";</script>';
    }
} else {
    // Jika akses langsung ke file ini tanpa melalui form
    echo '<script>window.location.href="index.php";</script>';
}
?>