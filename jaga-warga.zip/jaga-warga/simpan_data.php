<?php

include 'koneksi.php';

$no_kk = $_POST['no_kk'];
$nama_kep = $_POST['nama_kepala'];
$tgl = time();

$array1 =  $_POST['nik'];
$array2 =  $_POST['nama'];
$array3 =  $_POST['status'];
$array4 =  $_POST['pendidikan'];
$array5 =  $_POST['kelas'];
$array6 =  $_POST['pekerjaan'];
$array7 =  $_POST['penghasilan'];

$combinedArray = array_map(null, $array1, $array2, $array3, $array4, $array5, $array6, $array7);

// foreach ($combinedArray as $values) {
//     foreach ($values as $value) {
//         echo $value[0] . "<br>";
//     }
//     echo "------------<br>";
// }
$query = mysqli_query($koneksi, "INSERT INTO tbl_kk (no_kk, nama_kpl, tgl_input) VALUES ('$no_kk','$nama_kep','$tgl')");

foreach ($combinedArray as $values) {
    $placeholders = implode(", ", array_fill(0, count($values), "?"));
    $sql = "INSERT INTO tbl_warga_kk (nik, nama, stat, pendidikan, kelas, pekerjaan,
    penghasilan, no_kk) VALUES ($placeholders, $no_kk)";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("isssisi", ...$values);
    if ($stmt->execute()) {
        echo "<meta http-equiv='refresh' content='1 url=index.php'>";
    } else {
        echo "Error: " . $sql . "<br>" . $koneksi->error;
    }
    $stmt->close();
}

?>