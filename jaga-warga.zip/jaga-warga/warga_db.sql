-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 05:59 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warga_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kk`
--

CREATE TABLE `tbl_kk` (
  `no_kk` int(100) NOT NULL,
  `nama_kpl` varchar(255) NOT NULL,
  `tgl_input` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kk`
--

INSERT INTO `tbl_kk` (`no_kk`, `nama_kpl`, `tgl_input`) VALUES
(0, '', '1687013871'),
(454, 'aasds', '1687015473'),
(9876543, 'Jokowi', '1687013448'),
(12345678, 'Prabowo', '1687013296'),
(2147483647, 'Rusli', '1687015073');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_warga_kk`
--

CREATE TABLE `tbl_warga_kk` (
  `nik` int(100) NOT NULL,
  `nama` varchar(500) NOT NULL,
  `stat` varchar(50) NOT NULL,
  `pendidikan` varchar(100) NOT NULL,
  `kelas` int(3) NOT NULL,
  `pekerjaan` varchar(350) NOT NULL,
  `penghasilan` int(30) NOT NULL,
  `no_kk` int(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_warga_kk`
--

INSERT INTO `tbl_warga_kk` (`nik`, `nama`, `stat`, `pendidikan`, `kelas`, `pekerjaan`, `penghasilan`, `no_kk`) VALUES
(4564, 'asdas', 'Belum Menikah', 'Magister', 8, 'asda', 16654, 454),
(11111, 'Prabowo', 'Menikah', 'Diploma', 8, 'TNI', 6500000, 12345678),
(22222, 'Iriana Putri', 'Menikah', 'Sarjana', 8, 'Suster', 5000000, 12345678),
(33333, 'Raihan', 'Belum Menikah', 'SMA', 3, 'Pelajar', 0, 12345678),
(66666, 'Saputri cantika', 'Belum Menikah', 'SMA', 8, 'Freelance', 4500000, 9876543),
(77777, 'Sandika', 'Belum Menikah', 'Diploma', 8, 'Programmer', 5000000, 9876543),
(88888, 'Putri Canitka', 'Menikah', 'Sarjana', 8, 'IRT', 0, 9876543),
(99999, 'Jokowi', 'Menikah', 'Sarjana', 8, 'Presiden', 25000000, 9876543),
(525252, 'Anya ', 'Menikah', 'Sarjana', 8, 'Dokter', 8000000, 2147483647),
(6262626, 'Gilang', 'Belum Menikah', 'SMP', 2, 'Pelajar', 0, 2147483647),
(42424242, 'Rusli Zainal', 'Belum Menikah', 'Sarjana', 3, 'Programmer', 5000000, 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kk`
--
ALTER TABLE `tbl_kk`
  ADD PRIMARY KEY (`no_kk`);

--
-- Indexes for table `tbl_warga_kk`
--
ALTER TABLE `tbl_warga_kk`
  ADD PRIMARY KEY (`nik`),
  ADD KEY `a` (`no_kk`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_warga_kk`
--
ALTER TABLE `tbl_warga_kk`
  ADD CONSTRAINT `a` FOREIGN KEY (`no_kk`) REFERENCES `tbl_kk` (`no_kk`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
